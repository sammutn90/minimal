//Engine
const ENGINE_URL = "https://ec2-52-65-215-46.ap-southeast-2.compute.amazonaws.com/engine"
const SOURCE_TYPE = 45
const SOURCE_INDEX = 1
const SOURCE_KEY = "e5f09ad4-5912-4ee1-bf98-27eed640e539"
const VERSION = "3.0.1"

// Batching
const BATCH_INTERVAL_MS = 1000
const MAX_REQUESTS_PER_BATCH = 100
let batchTimeoutReached = true
let logEventsBatch = []

// Backoff
const BACKOFF_INTERVAL = 10000
let backoff = 0

const sleep = ms => {
    return new Promise(resolve => {
        setTimeout(resolve, ms)
    })
}

const scheduleBatch = async event => {
    if (batchTimeoutReached) {
        batchTimeoutReached = false
        await sleep(BATCH_INTERVAL_MS)
        if (logEventsBatch.length > 0) {
            event.waitUntil(postBatch(event))
        }
        batchTimeoutReached = true
    }
    return true
}

const fetchAndSetBackOff = async (nonameRequest, event) => {
    if (backoff <= Date.now()) {
        const resp = await fetch(ENGINE_URL, nonameRequest)
        if (resp.status === 403 || resp.status === 429) {
            backoff = Date.now() + BACKOFF_INTERVAL
        }
    }

    event.waitUntil(scheduleBatch(event))

    return true
}

const postBatch = async event => {
    const batchInFlight = [...logEventsBatch]
    logEventsBatch = []
    const body = JSON.stringify(batchInFlight)
    const request = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body,
    }
    event.waitUntil(fetchAndSetBackOff(request, event))
}

async function addToBatch(packetPair, requestClone, responseClone, event) {
    const requestBody = await requestClone.text()
    const responseBody = await responseClone.text()
    packetPair.http.request.body = requestBody
    packetPair.http.response.body = responseBody
    logEventsBatch.push(packetPair)
    if (logEventsBatch.length >= MAX_REQUESTS_PER_BATCH) {
        event.waitUntil(postBatch(event))
    }
    return true
}

async function handleRequest(event) {
    const requestClone = event.request.clone()
    const requestTs = Date.now()
    const response = await fetch(event.request)
    const responseClone = response.clone()
    const responseTs = Date.now()
    const requestCf = event.request.cf || {}
    const url = new URL(event.request.url)
    const urlParams = url.searchParams.toString().length === 0 ? '' : `?${url.searchParams}`
    const destPort = url.port || event.request.url.startsWith("https://") ? 443 : 80
    const destIp = "1.1.1.1"
    const requestHeaders = Object.fromEntries(event.request.headers)
    const responseHeaders = Object.fromEntries(response.headers)
    const sourceIp = requestHeaders["cf-connecting-ip"] || requestHeaders["x-real-ip"] || "0.0.0.0"
    let httpVersion = requestCf.httpProtocol
    httpVersion = httpVersion ? httpVersion.replace("HTTP/", "") : "1.1"
    let nonamePacket = {
        ip: {
            v: 4,
            src: sourceIp,
            dst: destIp
        },
        tcp: {
            src: 0,
            dst: destPort
        },
        http: {
            v: httpVersion,
            request: {
                ts: requestTs,
                method: event.request.method,
                url: url.pathname + urlParams,
                headers: requestHeaders,
                body: ''
            },
            response: {
                ts: responseTs,
                status: response.status,
                headers: responseHeaders,
                body: ''
            }
        },
        source: {
            type: SOURCE_TYPE,
            index: SOURCE_INDEX,
            key: SOURCE_KEY,
            version: VERSION,
        },
    }
    event.waitUntil(
      addToBatch(nonamePacket, requestClone, responseClone, event),
    )
    return response
}

addEventListener("fetch", event => {
    event.passThroughOnException()
    if (event.request.headers.get('upgrade') === 'websocket') {
        return event.respondWith(fetch(event.request))
    }
    event.waitUntil(scheduleBatch(event))
    event.respondWith(handleRequest(event))
})