$env:SystemDirectory = [Environment]::SystemDirectory
$IIS_Config = $env:SystemDirectory + "\inetsrv\config\applicationhost.config"
$appCmd = $env:SystemDirectory + "\inetsrv\appcmd.exe"
$nonameDllName = 'NonameNativeModule.dll'
$configFilePath = "$env:SystemRoot\system32\inetsrv\config\applicationHost.config"
$runtimeLibrariesName = 'VC_redist.x64.exe'
$dir = "NONAME_MODULE_INSTALL_DIR"

$sourceParams = @{
    NONAME_SOURCE_TYPE = "{{ NONAME_SOURCE_TYPE }}";
    NONAME_SOURCE_INDEX = "{{ NONAME_SOURCE_INDEX }}";
    NONAME_SOURCE_KEY = "{{ NONAME_SOURCE_KEY }}";
    NONAME_ENGINE_URL = "{{ NONAME_ENGINE_URL }}";
    NONAME_SOURCE_VERSION = "{{ NONAME_SOURCE_VERSION }}";
}

function Start-IIS {
    Start-Process "iisreset.exe" -ArgumentList "/start" -NoNewWindow -Wait
}

function Stop-IIS {
    Start-Process "iisreset.exe" -ArgumentList "/stop" -NoNewWindow -Wait
}

function Get-Install-Dir-Path([string]$InstallDir) {
    $moduleDir = "Noname Module"

    if (-Not $InstallDir) {
        return (Join-Path $Env:ProgramFiles $moduleDir)
    }
    elseif (Test-Path $InstallDir -IsValid) {
        return $InstallDir
    }
    throw "Invalid install directory provided '$InstallDir'"
}

function Copy-Noname-Module-To-Dir([string]$moduleDir) {
    if (!(Test-Path $moduleDir)) {
        New-Item -ItemType Directory -Path $moduleDir | Out-Null
    }
    $modulePath = Join-Path $moduleDir $nonameDllName
    Copy-Item -Path  ".\$nonameDllName" -Destination $modulePath -Force
    Write-Host -ForegroundColor Cyan "'$nonameDllName' copied to '$modulePath'."
    Set-Environment-Variable $dir $moduleDir
}

function Check-Runtime-Libraries {
    Write-Host -ForegroundColor Cyan "`nCheck for Visual C++ Redistributable packages"
    $PackagesFound = @{"2015-2022x64" = $False;}
    $Year = "2015-2022"
    $Architecture = "x64"
    & {
        Get-ChildItem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*
        Get-ChildItem HKLM:\SOFTWARE\WoW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*
    } | ForEach-Object {
        # Get the display name of each package
        $CurDisplayName = $_.GetValue("DisplayName")
        # Check if the display name matches the expected pattern for Visual C++ Redistributable
        if($CurDisplayName -match "^Microsoft Visual C\+\+\D*(?<Year>(\d|-){4,9}).*Redistributable.*") {
            # Extract the year and architecture from the display name
            $Year = $Matches.Year
            [Void] ($CurDisplayName -match "(?<Arch>(x86|x64))")
            $Architecture = $Matches.Arch
            # Update the hash table to indicate the package was found
            $PackagesFound[ '' + $Year + $Architecture ] = $True
        }
    }
    If ($PackagesFound.Values -notcontains $False ) {
        Write-Host -ForegroundColor Green "Success: All required versions of Microsoft Visual C++ were found and the VC runtime prereq has been satisfied."
        return $True
    }
    return $False
}

function Install-Runtime-Libraries {
    # https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
    if (-not (Check-Runtime-Libraries)) {
        Write-Host -ForegroundColor Cyan "Installing Runtime Libraries..."
        Start-Process -FilePath ".\$runtimeLibrariesName" /quiet -wait
    }
}

function Remove-Noname-Module-From-Dir([string]$moduleDir) {
    if (-not $moduleDir -or !(Test-Path $moduleDir)) {
        Write-Host -ForegroundColor Yellow "Warning: The given path does not exist. '$moduleDir' `n"
        return
    }
    # Check if the directory is empty
    $itemCount = (Get-ChildItem -Path $moduleDir).Count
    if ($itemCount -eq 0) {
        Write-Host -ForegroundColor Cyan "'$moduleDir' directory is empty."
    } else {
        $modulePath = Join-Path $moduleDir $nonameDllName
        Remove-Item -Path $modulePath -Force
        Write-Host -ForegroundColor Cyan "'$nonameDllName' removed from '$modulePath'."
    }
}

function Get-Environment-Variable([string]$envName) {
    return [System.Environment]::GetEnvironmentVariable($envName, [System.EnvironmentVariableTarget]::Machine)
}

function Set-Environment-Variable([string]$envName,[string]$envValue) {
    [System.Environment]::SetEnvironmentVariable($envName, $envValue,  [System.EnvironmentVariableTarget]::Machine)
}

function Create-Noname-Log {
    # get the default IIS log file path
    $logPath = Get-WebConfigurationProperty -Filter /system.applicationHost/sites/siteDefaults/logfile -Name directory
    # get the value for the directory property
    $logPath = $logPath.Value
    $logPath = $logPath.Replace("%SystemDrive%", "C:")
    $logPath = $logPath + "\noname"
    # Create noname logs directory if needed
    if (!(Test-Path $logPath)) {
        New-Item -ItemType Directory -Path $logPath | Out-Null
    }
    # set `Everyone` permissions
    $acl = Get-Acl $logPath
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "FullControl", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl $logPath $acl
    # set the log file path as environment variable
    $logPath = $logPath + "\noname.log"
    Set-Environment-Variable "NONAME_LOG_FILE_LOCATION" $logPath
}

function Set-Source-Parameters {
    foreach ($key in $sourceParams.Keys) {
        Set-Environment-Variable $key $sourceParams[$key]
    }
}

function Set-Azure-Metadata {
    try  {
        $azureResponse = Invoke-RestMethod -Uri "http://169.254.169.254/metadata/instance?api-version=2021-02-01" -Headers @{ "Metadata" = "true" } -UseBasicParsing
        $azureMetadata = @{}
        $azureMetadata["AzureResourceGroupName"] = $azureResponse.compute.resourceGroupName
        $azureMetadata["AzureSubscriptionId"] = $azureResponse.compute.subscriptionId
        $azureMetadata["AzureTags"] = $azureResponse.compute.tagsList | ConvertTo-Json -Depth 64 -Compress

        Write-Host -ForegroundColor Cyan "Azure Metadata:"
        $azureMetadata | Out-String | Write-Host -ForegroundColor Cyan
        foreach ($key in $azureMetadata.Keys) {
            $value = $azureMetadata[$key]
            Set-Environment-Variable $key $value
        }
    }
    catch {
        Write-Host -ForegroundColor Yellow "Not an AZURE instance."
    }
}

function Verify-Site-Name($siteName) {
    # Check if siteName exist in Windows server.
    $sites = Get-IISSite
    if (-Not $sites) {
        throw "[ERROR] IIS site does not exists in this server!`n" + $_
    }
    if ($siteName) {
        # Check if siteName exist in IIS-sites list.
        $siteFound = $false
        $sites = Get-IISSite $siteName
        foreach ($site in $sites) {
            if ($site.Name -eq $siteName) {
                $siteFound = $true
                break
            }
        }
        if (!$siteFound)
        { throw "[ERROR] IIS site name: '$siteName' does not exists in this server!`n" + $_ }
    }
}

function Add-Noname-Module-To-Site-Or-App($siteName) {
    $module = Get-WebConfiguration -Filter "/system.webServer/modules/add" -Location $siteName | Where-Object Name -eq 'NonameNativeModule'
    if (!$module) {
        Add-WebConfiguration -Filter "/system.webServer/modules" -Location $siteName -Value @{
            name = "NonameNativeModule"
        } -Force
        Write-Host -ForegroundColor Cyan "NonameNativeModule added to the '$siteName'."
    }
    else {
        Write-Host -ForegroundColor Yellow "Warning: NonameNativeModule already exists in the '$siteName'."
    }
}

function Remove-Noname-Module-From-Site-Or-App($siteName) {
    Remove-WebManagedModule -Name "NonameNativeModule"  -Location $siteName
    Write-Host -ForegroundColor Cyan "NonameNativeModule was removed from '$siteName'.`n"
}

function Disable-Global-Module-For-32bits-Sites {
    $webSites = Get-Website | Select-Object -ExpandProperty Name
    foreach ($webSite in $webSites) {
        $site = Get-IISSite -Name $webSite
        $appPool = Get-IISAppPool -Name $site.Applications[0].ApplicationPoolName
        if ($appPool.enable32BitAppOnWin64 -eq $true) {
            Write-Host -ForegroundColor Yellow "Warning: Your site '$site' has enable32BitAppOnWin64 set to True.
            Unfortunately, we must remove the NonameNativeModule."
            Disable-WebGlobalModule -Name "NonameNativeModule"  -Location $webSite
            Write-Host -ForegroundColor Cyan "NonameNativeModule was removed from '$webSite'.`n"
        }
    }
}

function Enable-Global-Module-For-32bits-Sites {
    $webSites = Get-Website | Select-Object -ExpandProperty Name
    foreach ($webSite in $webSites) {
        $site = Get-IISSite -Name $webSite
        $appPool = Get-IISAppPool -Name $site.Applications[0].ApplicationPoolName
        if ($appPool.enable32BitAppOnWin64 -eq $true) {
            Write-Host -ForegroundColor Cyan "Your site '$site' has enable32BitAppOnWin64 set to True.
            We are adding NonameNativeModule for future using."
            Enable-WebGlobalModule -Name "NonameNativeModule"  -Location $webSite
            Write-Host -ForegroundColor Cyan "NonameNativeModule was added to '$webSite'.`n"
        }
    }
}

function Get-32bit-App-Pool {
    $appPools = Get-IISAppPool
    foreach ($appPool in $appPools) {
        if ($appPool.enable32BitAppOnWin64 -eq $true) {
            return $appPool.Name
        }
    }
    return
}

function Register-Module {
    $globalModule = Get-WebConfiguration -Filter "/system.webServer/globalModules/add"  | Where-Object Name -eq 'NonameNativeModule'
    if (!$globalModule) {
        $moduleDir = Get-Environment-Variable($dir)
        $modulePath = Join-Path $moduleDir $nonameDllName
        Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
            name = "NonameNativeModule"
            image = $modulePath
            preCondition = "bitness64"
        } -Force
        Write-Host -ForegroundColor Cyan "NonameNativeModule added to the global modules at the 'applicationHost.config'."
    }
    else {
        Write-Host -ForegroundColor Yellow "Warning: NonameNativeModule already registered as a global module at the 'applicationHost.config'."
    }
}

function Unregister-Module {
    $globalModule = Get-WebConfiguration -Filter "/system.webServer/globalModules/add"  | Where-Object Name -eq 'NonameNativeModule'
    if ($globalModule) {
        $appPoolName = Get-32bit-App-Pool
        if ($appPoolName -ne $null) {
            Disable-Global-Module-For-32bits-Sites
        }
        Remove-WebGlobalModule -Name "NonameNativeModule"
        Write-Host -ForegroundColor Cyan "NonameNativeModule removed from global modules at the 'applicationHost.config'."
    }
    else {
        Write-Host -ForegroundColor Yellow "Warning: NonameNativeModule does not exists as a global module at the 'applicationHost.config'."
    }
}

function Configure-Module-Server-Level {
    $module = Get-WebConfiguration -Filter "/system.webServer/modules/add"  | Where-Object Name -eq 'NonameNativeModule'
    if (!$module) {
        $appPoolName = Get-32bit-App-Pool
        if ($appPoolName -ne $null) {
            Disable-Global-Module-For-32bits-Sites
        }
        Add-WebConfiguration -Filter "/system.webServer/modules" -Value @{
            name = "NonameNativeModule"
        } -Force
        Write-Host -ForegroundColor Green "NonameNativeModule added to modules at the 'applicationHost.config'."
    }
    else {
        Write-Host -ForegroundColor Yellow "Warning: NonameNativeModule already registered as a module at the 'applicationHost.config'."
    }
}

function Clear-Module-Server-Level {
    $module = Get-WebConfiguration -Filter "/system.webServer/modules/add"  | Where-Object Name -eq 'NonameNativeModule'
    if ($module) {
        $appPoolName = Get-32bit-App-Pool
        if ($appPoolName -ne $null) {
            Enable-Global-Module-For-32bits-Sites
        }
        Remove-WebManagedModule -Name "NonameNativeModule"
        Write-Host -ForegroundColor Green "NonameNativeModule removed from modules at the 'applicationHost.config'."
    }
    else  {
        Write-Host -ForegroundColor Yellow "Warning: NonameNativeModule does not exists as a module at the 'applicationHost.config'."
    }
}

function Install-Agent {
    try {
        Create-Noname-Log
        $moduleDir = Get-Install-Dir-Path $InstallDir
        Copy-Noname-Module-To-Dir $moduleDir
        Install-Runtime-Libraries
        Stop-IIS
        Set-Source-Parameters
        Set-Azure-Metadata
        Register-Module
        Write-Host -ForegroundColor Cyan "Install Agent completed successfully."
    }
    catch [System.SystemException] {
        $message = $_
        Write-Error "[ERROR] An error occurred.`n $message"
    }
    finally {Start-IIS}
}

function Uninstall-Agent {
    try {
        $ErrorActionPreference = "Stop"
        Stop-IIS
        Unregister-Module
        $moduleDir = Get-Environment-Variable($dir)
        Remove-Noname-Module-From-Dir $moduleDir
        Write-Host -ForegroundColor Cyan "Uninstall Agent completed successfully."
    }
    catch [System.SystemException] {
        $message = $_
        Write-Error "[ERROR] An error occurred.`n $message"
    }
    finally {Start-IIS}
}

function Add-Global-Noname-Module {
    try {
        $ErrorActionPreference = "Stop"
        Configure-Module-Server-Level
    }
    catch [System.SystemException] {
        $message = $_
        Write-Error "[ERROR] An error occurred.`n $message"
    }
}

function Remove-Global-Noname-Module {
    try {
        $ErrorActionPreference = "Stop"
        Clear-Module-Server-Level
    }
    catch [System.SystemException] {
        $message = $_
        Write-Error "[ERROR] An error occurred.`n $message"
    }
}

function Add-Website-Noname-Module($website) {
    try {
        $ErrorActionPreference = "Stop"
        $siteName = $website.Split('/')[0]
        Verify-Site-Name $siteName
        $site = Get-IISSite -Name $webSite
        $appPool = Get-IISAppPool -Name $site.Applications[0].ApplicationPoolName
        if ($appPool.enable32BitAppOnWin64 -ne $true) {
            Add-Noname-Module-To-Site-Or-App $website
        }
        else {
            throw "Your Application Pool '$($appPool.Name)' has enable32BitAppOnWin64 set to True.`n"
        }
    }
    catch [System.SystemException] {
        $message = $_
        Write-Error "[ERROR] An error occurred.`n $message"
    }
}

function Remove-Website-Noname-Module($website) {
    try {
        $ErrorActionPreference = "Stop"
        $siteName = $website.Split('/')[0]
        Verify-Site-Name $siteName
        Remove-Noname-Module-From-Site-Or-App $website
    }
    catch [System.SystemException] {
        $message = $_
        Write-Error "[ERROR] An error occurred.`n $message"
    }
}

Import-Module WebAdministration
Import-Module IISAdministration

Export-ModuleMember -Function Install-Agent
Export-ModuleMember -Function Uninstall-Agent

Export-ModuleMember -Function Add-Global-Noname-Module
Export-ModuleMember -Function Remove-Global-Noname-Module

Export-ModuleMember -Function Add-Website-Noname-Module
Export-ModuleMember -Function Remove-Website-Noname-Module
