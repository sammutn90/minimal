import requests
import json

def lambda_handler(event, context):
    # Define the hostname
    hostname = event.get('hostname', 'https://rea1.aph.staging.commbank.com.au/engine')
    
    try:
        # Send the request
        response = requests.get(hostname)
        
        # Return the response details
        return {
            'statusCode': response.status_code,
            'body': json.dumps({
                'headers': dict(response.headers),
                'content': response.text
            })
        }
    except requests.RequestException as e:
        # Log the error
        print(f'Error: {str(e)}')
        
        # Handle errors
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }
